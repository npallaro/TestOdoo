# -*- coding: utf-8 -*-

from . import voucher_create_invoice

